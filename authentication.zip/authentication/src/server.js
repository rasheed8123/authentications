const express = require("express")
const app = express();
app.use(express.json())
const connect = require("./configs/db")
const userscontroller = require("./controller/user.controller")
const {register,login} = require("./controller/auth.controller")
const postcontroller = require("./controller/post.controller")
app.use("/users",userscontroller)

app.post("/register",register)

app.post("/login",login)

app.use("/post",postcontroller)

app.listen(5000,async(req,res)=>{
    try{
     await connect()
    }catch(err){
        console.log(err.message)
        return res.send(err.message)
    }
    console.log("running")
})