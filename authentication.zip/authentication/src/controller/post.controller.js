const express = require("express");
const authenticate = require("../middlewares/authunticate");
const app = express.Router();
const post = require("../models/post.model")
const authenticate = require("../middlewares/authunticate")
app.post("",authenticate,async(req,res)=>{
    req.body.user_id = req.userID
 try{
    const product = await post.create(req.body)
    return res.status(200).send(product)
 }catch(err){
     console.log(err.message)
     return res.send(err.message)
 }
})
app.get("", authenticate,async (req, res) => {
    try{
        const product = await post.find()
        return res.status(200).send(product)
    }
    catch(err){
        return res.status(400).send({message : err.message})
    }
})
app.patch("/:id", authenticate,async (req, res) => {
    try{
        const product = await post.findByIdAndUpdate({user_id:req.params.id},{title:req.body.title},{body:req.body.body})
        return res.status(200).send(product)
    }
    catch(err){
        return res.status(400).send({message : err.message})
    }
})
app.delete("/:id", authenticate,async (req, res) => {
    try{
        const product = await post.findByIdAndDelete({user_id:req.params.id})
        return res.status(200).send(product)
    }
    catch(err){
        return res.status(400).send({message : err.message})
    }
})
module.exports = app;