const express = require("express")
const app = express.Router();
const user = require("../models/user.model")
const { body, validationResult } = require('express-validator');

app.post("/register",
body("name").not().isEmpty().withMessage("enter a valid name"),
body("email").isEmail().withMessage("enter the valid email"),
// body('email').custom(value => {
//     return User.find({email:value}).then(user => {
//       if (user) {
//         return Promise.reject('E-mail already in use');
//       }
//     });
//   })
async(req,res)=>{
    try{
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
          }
          let user1 = await user.findOne({email : req.body.email})
   

          if(user1){
              return res.status(400).send({message : "Email already exists" })
          }
  
          user2 = await user.create(req.body);
  
        //   const token = generateToken(user)
          return res.status(200).send(user2)
    }catch(err){
        console.log(err.message)
        return res.send(err.message)
    }
})
app.post("/login",async(req,res)=>{
    try{
        const user = await users.findOne({email : req.body.email})
        if(!user){
            return res.status(400).send("Wrong Email or Password")
        }
        if(user.email==req.body.email && user.password==req.body.password){
            return res.status(200).send(user)
        }
        return res.status(400).send("Wrong Email or Password")
    }catch(err){
        console.log(err.message)
    }
})
module.exports = app;